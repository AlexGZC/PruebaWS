-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 17-09-2016 a las 02:41:24
-- Versión del servidor: 5.6.12-log
-- Versión de PHP: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `mapas`
--
CREATE DATABASE IF NOT EXISTS `mapas` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `mapas`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lugares`
--

CREATE TABLE IF NOT EXISTS `lugares` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) DEFAULT NULL,
  `departamento` varchar(40) DEFAULT NULL,
  `municipio` varchar(50) DEFAULT NULL,
  `estrellas` int(6) DEFAULT NULL,
  `descripcion` varchar(300) DEFAULT NULL,
  `latlng` varchar(100) DEFAULT NULL,
  `idtipo` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_idtipo` (`idtipo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Volcado de datos para la tabla `lugares`
--

INSERT INTO `lugares` (`id`, `nombre`, `departamento`, `municipio`, `estrellas`, `descripcion`, `latlng`, `idtipo`) VALUES
(1, 'El Majahual', 'La Libertad', 'La Libertad', 4, 'Se genera un ambiente por lo general concurrido po', '13.4899124,-89.3834716', 1),
(12, 'dd', 'Sonsonate', 'Soyapango', 2, 'dwdsadasd', '1.2223,-3.2541', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos`
--

CREATE TABLE IF NOT EXISTS `tipos` (
  `idtipo` int(10) NOT NULL,
  `tipo` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`idtipo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tipos`
--

INSERT INTO `tipos` (`idtipo`, `tipo`) VALUES
(1, 'Playa'),
(2, 'Parques'),
(3, 'Museos');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `lugares`
--
ALTER TABLE `lugares`
  ADD CONSTRAINT `fk_idtipo` FOREIGN KEY (`idtipo`) REFERENCES `tipos` (`idtipo`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
