<?php 
class cnn
 {
 private $conexion;
   public function cnn()
     {
      if(!isset($this->conexion))
       { $this->conexion = (mysqli_connect("localhost","root","","mapas")) or die(mysqli_error()); }
     }

   public function consulta($consulta)
     { 
	 $resultado = mysqli_query($this->conexion,$consulta);
       return $resultado;                    }
 
   public function arreglo($consulta)
     { return mysqli_fetch_array($consulta); }

   public function conteo($consulta)
     { return mysqli_num_rows($consulta);   
	  }

 }   
?>