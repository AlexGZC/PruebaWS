<?php  
$dblink=new mysqli("localhost","root","","mapas") or die('No se pudo conectar: ');

?>