<?php 
 ob_start();
 session_start();
 require_once '../dbconnect.php';
 // if session is not set this will redirect to login page
 if( !isset($_SESSION['user']) ) {
  header("Location: ../index.php");
  exit;
}
 // select loggedin users detail
 $res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
 $userRow=mysql_fetch_array($res);
 ?>
<?php

include_once("conexion.php");

$resultado="";

// Realizar una consulta MySQL

$query = 'SELECT * FROM lugares';

if(isset($_GET["filtro"])){ 
	$filtro=$_GET["filtro"]; 
	if ($filtro == "id")

$query='SELECT * FROM lugares order by id asc';

else if($filtro == "nombre"){

$query="SELECT FROM lugares where nombre like '%" . $_GET["nombre"] ."%'"; 
}


}
$result = $dblink->query($query) or die('Consulta fallida. ');

while ($line = $result->fetch_assoc() ){ $lista[]=array_map('utf8_encode',$line);

}

$respuesta["status"]="";

$respuesta["respuesta"]="";

if(isset($lista)){

$resultado=$lista;

$respuesta["status"]="success";
$posts[] = array('post'=>$post);
$respuesta["respuesta"]=$resultado;

}else {

$resultado="No se encontró resultado";

$respuesta["status"]="error";

$respuesta["respuesta"]=$resultado;

}

header("Content-Type:application/json;charset=utf-8"); 
echo json_encode($respuesta);

$dblink->close();

?>

<?php ob_end_flush(); ?>
