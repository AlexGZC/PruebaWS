<?php
 ob_start();
 session_start();
 require_once 'dbconnect.php';
 // if session is not set this will redirect to login page
 if( !isset($_SESSION['user']) ) {
  header("Location: index.php");
  exit;
}
 // select loggedin users detail
 $res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
 $userRow=mysql_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
 <meta name="description" content="Servicios Web, UDB,DAS" />
    <meta name="author" content="Zetino,Alexander,Mario" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Opciones-Usuario:<?php echo $userRow['userEmail']; ?></title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="../css/formularios.css">
<link rel="icon" type="image/png" href="img/icono.png" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="http://www.parsecdn.com/js/parse-latest.js"></script>

</head>
<body>
<body>
<div class="container-fluid">
<div class="jumbotron">
  <h1 class="glyphicon glyphicon-cog"> Administración</h1>
</div>

<div class="row">
  <div class="col-lg-3">
    <ul class="list-group">
  <a href="agrega.php"><li class="list-group-item"><i class="glyphicon glyphicon-plus"></i> Agregar Datos</li></a>
  <a href="editar.php"><li class="list-group-item"><i class="glyphicon glyphicon-pencil"></i> Editar Datos</li></a>
  <a href="buscar.php"><li class="list-group-item"><i class="glyphicon glyphicon-search"></i> Buscar Datos</li></a>
  <a href="eliminar.php"><li class="list-group-item"><i class="glyphicon glyphicon-remove"></i> Eliminar Datos</li></a>
  <a href="resultado/generar.php"><li class="list-group-item"><i class="glyphicon glyphicon-check"></i> Generar JSON</li></a>
  <a href="logout.php?logout"><li class="list-group-item"><i class="glyphicon glyphicon-log-out"></i> Cerrar Sesión</li></a>
</ul>
</body>
</html>
<?php ob_end_flush(); ?>