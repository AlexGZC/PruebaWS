<?php
 ob_start();
 session_start();
 require_once 'dbconnect.php';
 // if session is not set this will redirect to login page
 if( !isset($_SESSION['user']) ) {
  header("Location: index.php");
  exit;
}
 // select loggedin users detail
 $res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
 $userRow=mysql_fetch_array($res);
?>

<!DOCTYPE html>
<html>
 <head>
 <meta name="description" content="Servicios Web, UDB,DAS" />
    <meta name="author" content="Zetino,Alexander,Mario" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Buscar-Usuario:<?php echo $userRow['userEmail']; ?></title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="../css/formularios.css">
<link rel="icon" type="image/png" href="img/icono.png" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="http://www.parsecdn.com/js/parse-latest.js"></script>

<body>

<nav class="nav nav-tabs nav-justified" >
        <div class="container-fluid">
           
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle glyphicon glyphicon-menu-hamburger" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Navegación</span>
           
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#inicio">Sitios</a>
            </div>

            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#inicio"></a>
                    </li>
                    <li class="page-scroll">
                        <a href="opciones.php">Inicio</a>
                    </li>
                    <li class="page-scroll">
                        <a href="agrega.php">Agregar</a>
                    </li>
                    <li class="page-scroll">
                        <a href="editar.php">Editar</a>
                    </li>
                   <li class="page-scroll">
                        <a class="glyphicon glyphicon-log-out" href="logout.php?logout"><br>Salir /<?php echo $userRow['userEmail']; ?></a>
                    </li>
                </ul>
            </div>
         
        </div>
    </nav>
<br><br>

<div class="panel-primary">
  <div class="panel-heading">
  <h2>Buscar</h2>
  </div>
  <div class="panel-body" >
<form class="form-horizontal" method="post" action="" rol="form">

<div class="form-group">
<label class="col-lg-2 control-label">Nombre</label>
    <div class="col-lg-10">
<input type="Text" name="nombre" required="required" placeholder="Ingrese nombre del sitio">
</div>
</div>

<div class="form-group">
    <div class="col-lg-offset-3 col-lg-10">
<input type="Submit" class="btn btn-primary" name="buscar" value="Buscar">
</div>
</div>
</form>
</div>
</div>

<hr>

<div class="container">

<div class="panel-primary">
  <div class="panel-heading">
  <h2>Lista de canciones</h2>
  </div>
  <div class="panel-body">
 
  
  <?php
  
if(isset($_POST["buscar"])) {

  $nombre = $_POST["nombre"] ;
  require("cnn_conexion.php");
  $xyz = new cnn();
  $sql=$xyz->consulta("SELECT * FROM lugares WHERE nombre LIKE '%".$nombre."%'");
  
      $i=0;
      if(mysqli_num_rows($sql)<1){
        echo "La busqueda no obtuvo resultados."; 
      }else{
        echo " 
        <table collspan='2' class='table table-hover'>
        <tr>
        <th >Codigo    </th>
        <th>Nombre   </th>
        <th>Tipo   </th>
        <th>Latlng   </th>
        </tr>";
      while($ver= mysqli_fetch_array($sql))
      {
      echo "<tr class='success'><td>".$ver["id"]."</td>";
      echo "<td>".$ver["nombre"]."</td>";
      echo "<td>".$ver["idtipo"]."</td>";
      echo "<td>".$ver["latlng"]."</td></tr>";
      $i++;


  }
}
}

?>
  </table>
  </div>
</div>
</div>


<!-- Latest compiled and minified JavaScript -->
  <script src="https://code.jquery.com/jquery-3.1.0.min.js" integrity="sha256-cCueBR6CsyA4/9szpPfrX3s49M9vUU5BgtiJj06wt/s=" crossorigin="anonymous"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

</body>
</html>
<?php ob_end_flush(); ?>